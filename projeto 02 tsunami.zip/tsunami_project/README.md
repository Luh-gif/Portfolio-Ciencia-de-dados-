
# Projeto de Previsão de Tsunamis (Dados de Terremotos)

## Objetivo
Prever se um evento sísmico pode gerar um tsunami (`tsunami` = 1).

Este projeto usa dados históricos de terremotos e aplica técnicas de **Ciência de Dados e Machine Learning** para identificar padrões que aumentam a probabilidade de formação de tsunamis.

## O que está incluído no projeto

- `figures/` → gráficos de análise exploratória dos dados (EDA)
- `models/` → modelo treinado em sklearn + metadados
- `train.py` → script para treinar novamente o modelo
- `predict.py` → exemplo de como carregar o modelo e fazer previsões
- `report.md` → relatório do projeto com análise dos dados

## Como executar o projeto

### 1. Instalar dependências

```bash
pip install -r requirements.txt
```

### 2. Treinar o modelo

```bash
python train.py --input earthquake_data_tsunami_cleaned.csv
```

### 3. Fazer previsões

```bash
python predict.py --model models/rf_tsunami_pipeline.joblib --threshold <valor> --input novos_dados.csv
```

## Observações

- O modelo foi ajustado para priorizar **alto recall**, ou seja, reduzir a chance de não detectar um tsunami.
- Em aplicações reais, é importante avaliar o custo de **falsos positivos vs falsos negativos**.
- Este projeto é um exemplo educacional de **pipeline de Machine Learning aplicado a dados geofísicos**.
