import argparse
import json
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.ensemble import RandomForestClassifier


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--out_model', default='models/rf_tsunami_pipeline.joblib')
    parser.add_argument('--out_meta', default='models/model_metadata.json')
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    X = df.drop(columns=['tsunami'])
    y = df['tsunami'].astype(int)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    num_cols = [c for c in X_train.columns if pd.api.types.is_numeric_dtype(X_train[c])]
    preprocess = ColumnTransformer(
        transformers=[('num', Pipeline([('imputer', SimpleImputer(strategy='median')),
                                       ('scaler', StandardScaler())]), num_cols)],
        remainder='drop'
    )

    model = RandomForestClassifier(
        n_estimators=500,
        random_state=42,
        class_weight='balanced_subsample',
        min_samples_leaf=2,
        n_jobs=-1
    )

    pipe = Pipeline([('preprocess', preprocess), ('model', model)])

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(pipe, X, y, cv=cv, scoring='roc_auc')

    pipe.fit(X_train, y_train)
    proba = pipe.predict_proba(X_test)[:, 1]

    meta = {
        'numeric_features_used': num_cols,
        'cv_roc_auc_scores': [float(x) for x in cv_scores],
        'cv_roc_auc_mean': float(np.mean(cv_scores)),
        'cv_roc_auc_std': float(np.std(cv_scores)),
        'test_roc_auc': float(roc_auc_score(y_test, proba)),
        'test_pr_auc': float(average_precision_score(y_test, proba))
    }

    joblib.dump(pipe, args.out_model)
    with open(args.out_meta, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)


if __name__ == '__main__':
    main()
