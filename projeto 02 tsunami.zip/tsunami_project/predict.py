import argparse
import pandas as pd
import joblib


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--input', required=True)
    parser.add_argument('--threshold', type=float, default=0.5)
    parser.add_argument('--output', default='predictions.csv')
    args = parser.parse_args()

    pipe = joblib.load(args.model)
    df = pd.read_csv(args.input)
    proba = pipe.predict_proba(df)[:, 1]
    pred = (proba >= args.threshold).astype(int)

    out = df.copy()
    out['tsunami_proba'] = proba
    out['tsunami_pred'] = pred
    out.to_csv(args.output, index=False)


if __name__ == '__main__':
    main()
