
# Relatório de Análise — Previsão de Tsunamis

## 1. Introdução

Tsunamis são fenômenos naturais extremamente destrutivos que geralmente são causados por terremotos submarinos.

O objetivo deste projeto é analisar dados históricos de terremotos e treinar um modelo de **Machine Learning** capaz de prever a probabilidade de um terremoto gerar um tsunami.

---

## 2. Dados Utilizados

A base de dados contém informações como:

- Magnitude do terremoto
- Profundidade
- Latitude e longitude
- Intensidade sísmica
- Distância mínima a estações de medição
- Gap azimutal
- Ano e mês do evento

Variável alvo:

`tsunami`

- 0 → não gerou tsunami
- 1 → gerou tsunami

---

## 3. Análise Exploratória

Foram gerados alguns gráficos importantes:

- Distribuição da variável alvo
- Relação entre magnitude e profundidade
- Mapa de correlação entre variáveis

Essas análises ajudam a entender quais variáveis possuem maior relação com a ocorrência de tsunamis.

---

## 4. Modelo Utilizado

Foi utilizado um modelo:

**Random Forest Classifier**

Motivos da escolha:

- Lida bem com dados não lineares
- Funciona bem com variáveis numéricas
- Robusto a outliers
- Fácil interpretação relativa de importância das variáveis

---

## 5. Pipeline de Machine Learning

O pipeline inclui:

1. Preparação dos dados
2. Separação treino/teste
3. Treinamento do modelo
4. Avaliação do modelo
5. Ajuste de threshold de decisão

O modelo treinado foi salvo para uso posterior.

---

## 6. Possíveis Melhorias

Algumas melhorias possíveis:

- Adicionar dados geográficos mais detalhados
- Incluir distância da costa
- Testar modelos como XGBoost ou LightGBM
- Criar um dashboard em Power BI ou Streamlit

---

## 7. Conclusão

O projeto demonstra como técnicas de **Ciência de Dados** podem ser usadas para identificar padrões em fenômenos naturais complexos.

Mesmo sendo um projeto educacional, ele mostra um pipeline completo de:

- análise de dados
- modelagem
- avaliação
- deploy de modelo
